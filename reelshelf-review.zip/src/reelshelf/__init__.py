"""ReelShelf application package."""
