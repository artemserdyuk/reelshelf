"""Repository implementations for ReelShelf."""
