"""HTTP interface for ReelShelf."""
