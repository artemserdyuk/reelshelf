"""Service implementations for ReelShelf."""
