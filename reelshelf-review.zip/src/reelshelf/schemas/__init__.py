"""Schema definitions for ReelShelf."""
