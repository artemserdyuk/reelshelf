"""Core configurations and settings."""
